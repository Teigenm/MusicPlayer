package com.tangguogen.musicplayer_teigen.ui.home;

import androidx.appcompat.app.AppCompatActivity;
import com.tangguogen.musicplayer_teigen.R;
import com.tangguogen.musicplayer_teigen.app.ToolbarActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class HistoryActivity extends ToolbarActivity {

    public static void go(Context context){
        Intent intent = new Intent();
        intent.setClass(context,HistoryActivity.class);
        context.startActivity(intent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_layout);
    }
}
