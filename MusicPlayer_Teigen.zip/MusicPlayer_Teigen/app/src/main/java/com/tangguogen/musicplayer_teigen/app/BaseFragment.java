package com.tangguogen.musicplayer_teigen.app;

import androidx.fragment.app.Fragment;

/**
 * Class description:
 *
 * @author tgg
 * @version 1.0
 * @see BaseFragment
 * @since 2019/3/26
 */
public abstract class BaseFragment extends Fragment {
}
