package com.tangguogen.musicplayer_teigen.app;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Class description:
 *
 * @author tgg
 * @version 1.0
 * @see BaseActivity
 * @since 2019/3/6
 */
public abstract class BaseActivity extends AppCompatActivity {
}
